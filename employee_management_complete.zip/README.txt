Employee Management Website

Files included:
- index.html: complete self-contained website (HTML, CSS, JavaScript).
- README.txt: these instructions.

Run locally:
1. Extract the ZIP.
2. Open index.html in a modern browser.

Publish on GitHub Pages / static hosting:
1. Upload index.html to the repository root (not inside another folder).
2. Commit/push the file.
3. Configure Pages to deploy from the branch and root folder (/).

Notes:
- No separate CSS, JavaScript, image, or dependency files are required for this version.
- Employee records and theme settings are stored in the browser local storage.
- WhatsApp buttons open WhatsApp with a prepared message; they do not send messages automatically.
- Sample employee names and phone numbers are placeholders; replace them before production use.
- Local storage does not synchronize records between users or devices.
